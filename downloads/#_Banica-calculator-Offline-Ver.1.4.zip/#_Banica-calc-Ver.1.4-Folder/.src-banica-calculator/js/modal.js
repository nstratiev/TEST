// let modalActivatorElem = null;

// export function showModal(ev) {
//   modalActivatorElem = ev.target;

//   modalBoxElem.style.display = 'flex';
//   disableForm(formMain);
//   btnModal.focus();
// }

// export function hideModal() {
//   modalBoxElem.style.display = 'none';
//   enableForm(formMain);
// }

// export function onModalConfirm() {
//   hideModal();
//   modalActivatorElem.focus();
// }


// // import { modalActivatorElem } from "./index.js";
// import { formMain } from './elements.js';
// import { disableForm, enableForm } from "./generic.js";